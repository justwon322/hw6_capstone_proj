from flask import Flask, request, jsonify
import sys
import argparse
from fastai.vision import *
from PIL import Image
from functools import lru_cache
import io

learn = None
app = Flask(__name__, instance_relative_config=True)

@app.route("/predict", methods=['POST'])
def predict():
	image=request.files['img']
	img = open_image(BytesIO(image.read()))
	
	pred,_,losses = learn.predict(img)
	
	return jsonify({"result":str(pred)})
#	return jsonify({
#		"predictions": sorted(
#			zip(learn.data.classes, map(float, losses)),
#			key=lambda p: p[1],
#			reverse=True
#		)
#	})

@lru_cache(maxsize=None)
def loadModel(path):
	try:
		global learn
		learn = load_learner(path)
		print("leaner load succeed")
	except:
		raise
	return learn
	

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument("--port", help="port for web application", default=9000)
	parser.add_argument("--modelpath", help="model path that expoted by fastai")
	args = parser.parse_args()
	
	loadModel(args.modelpath)
		
	app.run(host='0.0.0.0', port=args.port)